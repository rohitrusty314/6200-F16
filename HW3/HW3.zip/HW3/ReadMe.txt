HW3

Language: Python 
Version: 3.5

I. Program Setup:

	1. Double click get-pip.py (attached)
	3. Open command window, type pip and press enter 
           (details on how pip is to be used should come)	
	4. Install BeautifulSoup: on command window type
	   pip install beautifulsoup4
	5. Open Python shell, type
           import bs4
   	   and hit enter. If there is no error it is installed correctly.

II. Program Run:

	Double click the .py file. This should run the program. 

III. Design choices:

     For Task 1:
	Read each raw html data from txt file
	Parse using a HTML parser
	split each word as token on the basis of white space and new-line
	Process each token to remove unwanted data
	Write to the token file

     For Task 2:
	The inverted index is being stored using data structure 'dict' in python
	They key will be the token read from each file generated from task 1
	Value for each key will a list of tuples
	a tuple in this list will store the docid and frequency of the token in the specified document
	
	This process is iterated for all the files that have been cleaned from task 1.


IV. Program File Organisation:
	
	Task 1: 
	Source Code file: task1.py
	Required: 1. Raw html data in .txt file in folder "1_Unfocussed_pages"
		     this can be cahnged in the source code at the location specified
                  2. Assumption: the file names are same as the title of the page
	Output files: 1. A new folder gets created, "Cleaned_Text"
		      2. All the clean token files are created in this folder 
                         under the name same as the title(as per the assumption)
                         resmoving all the hyphens and underscores from the file name

	Task 2:
	Source Code file: task2.py
        Required: Tokenised files present in the folder "Cleaned_Text"
	Output: 1. 1_gram_indices.txt 
	           one-gram inverted index file
		
	 	2. 2_gram_indices.txt 
	           two-gram inverted index file
		
	 	3. 3_gram_indices.txt 
	           three-gram inverted index file
		

	Task 3:
	Output: 1. 1_gram_frequency.txt
		   one-gram term frequency file

		2. 1_gram_df.txt
		   one-gram document frequency file

		3. 2_gram_frequency.txt
		   two-gram term frequency file

		4. 2_gram_df.txt
		   one-gram document frequency file

		5. 3_gram_frequency.txt
		   three-gram term frequency file

		6. 3_gram_df.txt
		   three-gram document frequency file

		7. stop_list.txt
		   List of stop words

		8. stop_list_reasoning.txt
		   Explanation for choosing cutoff to generate the stop list
		
		9. doc_docid_map.txt
		   Mapping of which document id corresponds to which document name

	Bonus: 
	Source Code: 1gramgraph.py
		     2gramgraph.py
		     3gramgraph.py
		     Generates the graphs respectively.
	
	Required: 1_gram_frequency.txt
		  2_gram_frequency.txt
		  3_gram_frequency.txt
		  Frequenct files for each index.
	
	Output: Zipf_plot_1gram.png
		Zipf_plot_1gram.png
		Zipf_plot_2gram.png

       Other Files:
	get-pip.py
	To help install pip. Assisting in installation of beautifulsoup4
		   




