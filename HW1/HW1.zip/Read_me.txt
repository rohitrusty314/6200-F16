Language: Python 
Version: 3.5

I. Program Setup:

	1. Double click get-pip.py (attached)
	3. Open command window, type pip and press enter 
           (details on how pip is to be used should come)	
	4. Install BeautifulSoup: on command window type
	   pip install beautifulsoup4
	5. Open Python shell, type
           import bs4
   	   and hit enter. If there is no error it is installed correctly.

II. Program Run:

	Double click the .py file. This should run the program. 

III. Program File Organisation:

     1. Task 1: Unfocussed Crawl
        File Name: 1_Unfocussed_Crawler.py
        Output links file: 1_Unfocused_Url_list.txt
	Depth 1: https://en.wikipedia.org/wiki/Sustainable_energy

      2. Task 2A: Focussed Breadth First Crawl 
	 File Name: 2_Focused_BFS_Crawler.py
         Output links file: 2_Focused_Url_list.txt
 	 Depth 1: https://en.wikipedia.org/wiki/Sustainable_energy

      3. Task 2B: Focussed Depth First Crawl
         File Name: 3_Focussed_DFS_Crawler.py
	 Output links file: 2_Focussed_DFS_Url_list
 	 Depth 1: https://en.wikipedia.org/wiki/Sustainable_energy


      4. Task 3: Focussed Crawl
	 File Name: 4_Unfocussed_crawler_seed2.py
	 Output links file: 4_Unfocused_Url_list_seed2.txt
	 Depth 1: https://en.wikipedia.org/wiki/Solar_power

IV. Other files attached
	
	1. Task 2C: Comparison between DFS and BFS
	   File Name: Task2C.txt

	2. Task 3: Approach for merging the results Task 1 and Task 3
	   File Name: Task3.txt

	3. get-pip.py
	   To help install pip. Assisting in installation of beautifulsoup4


